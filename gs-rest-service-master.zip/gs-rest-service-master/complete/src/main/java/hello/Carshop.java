package hello;

import java.util.List;

public class Carshop {

	public static List<Carmodel> carmodels;
	public static List<Employee> employees;
	public static List<Sale> sales;



    public Carshop() {
    }

}
